# Text Based Game
# Dustyn Bartles
# 3/9/22
# Jr
# ------------------

def loadMap():
    H1A1 = "You: I'm in the start of the walk-in hallway.. Why am i here? I just wanna wake up.."

    H2A2 = "You: I'm in the middle of the walk-in hallway.."

    H3A3 = "You: I'm at the end of the walk-in hallway."

    H4A4 = "You: Another hallway.. greaaattt. I'm at the start of the bedroom hallway.."

    H5A5 = "You: I'm in the middle of the bedroom hallway.. Man I'm tired of this. "

    H6A6 = "You: Does it ever end? I'm still in the middle of the bedroom hallway somehow.."

    H7A7 = "You: FINALLY. I'm at the end of the bedroom hallway.."

    H8A8 = "You: THE DINING ROOM! so many good memories here.. and bad."

    H9A9 = "You: was never aloud over here.. (At The Locked Door) "

    H10A10 = "You: Great food was cooked here at one point.. (The Kitchen)"

    H11A11 = "You: I'm at the beginning of the Laundry room.."

    H12A12 = "You: I'm at the end of the Laundry room.. Aka near the backdoor."

    R1A1 = "You: The bathroom.. nothing really special here.."

    R2A2 = "You: My old bedroom! *In the corner of the room you see the computer glowing the letter (E)*"

    R3A3 = "You: My sisters room.. *On  the TV the letter (V) shows*" \
           "E V ?"

    R4A4 = "You: My parents room.. Man im getting emotional, It all looks just as i remembered. " \
           "*You hear a voice say the letter I* " \
           "Please just let me go home!"

    R5A5 = "You: My parents bathroom.. nice *You see a bloody letter L on the mirror* " \
           "An L? E V I L.. EVIL?"

    R6A6 = "You: My parents always kept this room locked and never let me in it.." \
           "what is all this??.. Just let out of here!"

    R7A7 = "You: I'm at the backdoor.. and of course its locked. I need the keys"

    R8A8 = "You: The old living room! so many memories here.. "


                                        # Hallways

    myMap = {"H1": {"LocDesc": H1A1, "e": "No", "w": "No", "n": "H2", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H2": {"LocDesc": H2A2, "e": "R8", "w": "No", "n": "H3", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H3": {"LocDesc": H3A3, "e": "No", "w": "H4", "n": "H8", "s": "H2", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H4": {"LocDesc": H4A4, "e": "H3", "w": "H5", "n": "R1", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H5": {"LocDesc": H5A5, "e": "H4", "w": "H6", "n": "No", "s": "R2", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H6": {"LocDesc": H6A6, "e": "H5", "w": "H7", "n": "No", "s": "R3", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H7": {"LocDesc": H7A7, "e": "H6", "w": "No", "n": "R4", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H8": {"LocDesc": H8A8, "e": "H10", "w": "No", "n": "H9", "s": "H3", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H9": {"LocDesc": H9A9, "e": "No", "w": "R6", "n": "No", "s": "H8", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H10": {"LocDesc": H10A10, "e": "No", "w": "H8", "n": "H11", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "H11": {"LocDesc": H11A11, "e": "H12", "w": "No", "n": "No", "s": "H10", "puzzle": "No", "lock": "No",
                     "rsound": "No", "count": 0},

             "H12": {"LocDesc": H12A12, "e": "No", "w": "H11", "n": "No", "s": "R7", "puzzle": "No", "lock": "No",
                     "rsound": "No", "count": 0},

                                        # Rooms

             "R1": {"LocDesc": R1A1, "e": "No", "w": "No", "n": "No", "s": "H4", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "R2": {"LocDesc": R2A2, "e": "No", "w": "No", "n": "H5", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "R3": {"LocDesc": R3A3, "e": "No", "w": "No", "n": "H6", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "R4": {"LocDesc": R4A4, "e": "R5", "w": "No", "n": "No", "s": "H7", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "R5": {"LocDesc": R5A5, "e": "No", "w": "R4", "n": "No", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "R6": {"LocDesc": R6A6, "e": "H9", "w": "No", "n": "No", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "R7": {"LocDesc": R7A7, "e": "No", "w": "No", "n": "H12", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0},

             "R8": {"LocDesc": R8A8, "e": "No", "w": "H2", "n": "No", "s": "No", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0}}

    return myMap


def checkDirection(direction, currLoc):
    LowerD = direction.casefold()
    newSpot = currLoc.get(LowerD)
    # print(newSpot)
    if newSpot != "No":
        return newSpot
    else:
        return None

maplist = loadMap()
startLoc = "H1"
prePlayerLoc = startLoc
playerLoc = startLoc
keepPlaying = True
while keepPlaying:
    currLoc = maplist.get(playerLoc)
    lockName = currLoc.get("lock")
    puzzleName = currLoc.get("puzzle")
    currLoc["count"] += 1
   # print(f"Lock : {lockName} and Puzzle : {puzzleName}")
    print(currLoc.get("LocDesc"))

    prompt = "\n" + "You: Where should I go next? (N) (E) (S) (W) : "
    playerAction = input(prompt)
    prevPlayerLoc = currLoc

    if playerAction.lower() == "q":
        keepPlaying = False
    else:
        newLoc = checkDirection(playerAction.lower(), currLoc)

        if newLoc != None:
            playerLoc = newLoc
        else:
            print("You: I can't go that way..")





